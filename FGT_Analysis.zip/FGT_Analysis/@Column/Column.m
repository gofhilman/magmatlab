classdef Column
    %COLUMN Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Constant)
        frequency = 1;
        field = 2;
        gain = 3;
        resonanceField = 2;
        fwhm = 3
    end
end

